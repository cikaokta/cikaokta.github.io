<?php 
$koneksi = mysqli_connect("localhost","root","","spforwardcf3");
?>